#include<stdio.h>
void fun()
{
  char s[12];
  printf("Return to fun!\n");
}

void main()
{
  fun();
}
