#include <stdio.h>

int main(){
    unsigned long str_addr = 0xff000000;

    while(str_addr < 0xffff0000){

    }

}
