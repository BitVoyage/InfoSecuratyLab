#ifndef HANDLE_H
#define HANDLE_H

#include "http-tree.h"

void Handle_main (int fd, Http_t tree);

#endif
