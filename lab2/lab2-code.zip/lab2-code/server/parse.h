#ifndef PARSE_H
#define PARSE_H

#include "http-tree.h"

Http_t Parse_parse(int fd);

#endif
